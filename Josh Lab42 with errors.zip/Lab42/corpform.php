<?php
/**
 * Created by PhpStorm.
 * User: 001386538
 * Date: 10/23/2017
 * Time: 8:12 AM
 */
// FORM FOR USERS TO ADD INFO INTO DATABASE
?>
<form method="post" action="#">
    Corp: <input type="text" name="corp" value="" /> <br>
    Email: <input type="text" name="email" value="" /> <br>
    Zip Code: <input type="text" name="zipcode" value="" /> <br>
    Owner: <input type="text" name="owner" value="" /> <br>
    Phone number: <input type="text" name="phone" value="" /> <br>
    <input type="submit" id="foo" name="action" value="Submit" />
</form>
